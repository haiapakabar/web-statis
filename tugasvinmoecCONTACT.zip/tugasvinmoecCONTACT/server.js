require('dotenv').config();
const express = require('express');
const path = require('path');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
const nodemailer = require('nodemailer');

const app = express();
const PORT = process.env.PORT || 3000;

app.use(helmet());
app.use(express.json({ limit: '10kb' }));
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname)));

// Basic rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 20, // limit each IP to 20 requests per windowMs
  message: { error: 'Terlalu banyak permintaan, coba lagi nanti.' }
});
app.use('/contact', limiter);

// Simple input sanitizer
function sanitize(input) {
  return String(input || '').replace(/[<>]/g, '');
}

// Create transporter using SMTP credentials from env
function createTransporter() {
  if (!process.env.SMTP_HOST || !process.env.SMTP_USER || !process.env.SMTP_PASS) {
    console.error('Missing SMTP configuration in environment variables.');
    return null;
  }

  return nodemailer.createTransport({
    host: process.env.SMTP_HOST,
    port: Number(process.env.SMTP_PORT) || 587,
    secure: process.env.SMTP_SECURE === 'true' || false,
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS
    }
  });
}

app.post('/contact', async (req, res) => {
  try {
    const name = sanitize(req.body.name);
    const email = sanitize(req.body.email);
    const message = sanitize(req.body.message);

    if (!name || !email || !message) {
      return res.status(400).json({ error: 'Nama, email, dan pesan diperlukan.' });
    }

    const transporter = createTransporter();
    if (!transporter) return res.status(500).json({ error: 'Server belum dikonfigurasi untuk mengirim email.' });

    const mailOptions = {
      from: `${name} <${process.env.SMTP_USER}>`,
      replyTo: email,
      to: process.env.EMAIL_TO || 'vinmoec@gmail.com',
      subject: `Kontak dari situs - ${name}`,
      text: `Nama: ${name}\nEmail: ${email}\n\nPesan:\n${message}`
    };

    await transporter.sendMail(mailOptions);
    return res.json({ success: true });
  } catch (err) {
    console.error('Error sending email:', err);
    return res.status(500).json({ error: 'Gagal mengirim pesan.' });
  }
});

app.listen(PORT, () => {
  console.log(`Server berjalan di http://localhost:${PORT}`);
});
