Setup dan menjalankan contact form backend (Node.js)

1) Instal dependensi

```bash
npm install
```

2) Buat file `.env` berdasarkan `.env.example` dan isi kredensial SMTP.
   - Jika menggunakan Gmail, buat App Password dan pakai di `SMTP_PASS`.

3) Jalankan server

```bash
npm start
```

4) Buka di browser:

http://localhost:3000

Keamanan dan catatan:
- Server memakai `helmet` dan `express-rate-limit` untuk perlindungan dasar.
- Simpan kredensial SMTP di environment, jangan commit ke repo.
- Untuk produksi, pertimbangkan menambahkan reCAPTCHA, validasi lebih ketat, logging, dan pembatasan origin.
