// Client-side form handler
document.addEventListener('DOMContentLoaded', () => {
  const form = document.getElementById('contactForm');
  const submitBtn = form.querySelector('.submit-btn');

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    submitBtn.disabled = true;
    submitBtn.textContent = 'Mengirim...';

    const name = document.getElementById('nama').value.trim();
    const email = document.getElementById('email').value.trim();
    const message = document.getElementById('pesan').value.trim();

    if (!name || !email || !message) {
      alert('Semua field wajib diisi.');
      submitBtn.disabled = false;
      submitBtn.textContent = 'KIRIM';
      return;
    }

    try {
      const res = await fetch('/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, message })
      });

      if (res.ok) {
        alert('Pesan berhasil dikirim. Terima kasih!');
        form.reset();
      } else {
        const data = await res.json().catch(() => ({}));
        alert('Gagal mengirim: ' + (data.error || res.statusText));
      }
    } catch (err) {
      alert('Terjadi kesalahan: ' + err.message);
    }

    submitBtn.disabled = false;
    submitBtn.textContent = 'KIRIM';
  });
});
